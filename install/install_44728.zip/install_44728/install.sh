#!/bin/sh
echo "Installing..."
echo "sudo chmod 755 /usr/local/lib"
echo "cp -n *.dylib /usr/local/lib"
mkdir ~/Desktop/LMTools
cp LMTools.zip ~/Desktop/LMTools
unzip ~/Desktop/LMTools/LMTools.zip -d ~/Desktop/LMTools/
echo "Done!"
